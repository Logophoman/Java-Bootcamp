package MauMau;

public class Karte {
    private String farbe;
    private int wert;

    public Karte(String farbe, int wert) {
        this.farbe = farbe;
        this.wert = wert;
    }

    public String getFarbe() {
        return farbe;
    }

    public int getWert() {
        return wert;
    }

    @Override
    public String toString() {
        return this.farbe + " " + this.wert;
    }

    public boolean spielbar(Karte k) {
        return farbe.equals(k.farbe) || wert == k.wert;
    }
}
