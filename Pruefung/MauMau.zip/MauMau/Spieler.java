package MauMau;

import java.util.ArrayList;

public abstract class Spieler {
private int spielerNummer;
static int spielerAnzahl = 0;
private static final int STARTKARTEN_ANZAHL = 7;
private Kartendeck spielkarten;
private ArrayList<Karte> handkarten;
//StringBuilder sb = new StringBuilder();

public Spieler(Kartendeck spielkarten) {
    this.spielkarten = spielkarten;         // Initialisieren der übergebenen Parameter
    spielerAnzahl++;                        // beim Anlegen eines Spielers erhöht sich die (globale) Spieleranzahl um 1
    spielerNummer = spielerAnzahl;          // beim Anlegen eines Spielers bekommt dieser eine Spielernummer entsprechend der Spieleranzahl
    handkarten = new ArrayList<Karte>();
    for (int i = 0; i < STARTKARTEN_ANZAHL; i++) {
        ziehen();
    }
}
    public int getSpielerNummer() {
        return spielerNummer;
    }

    public Kartendeck getSpielkarten() {
        return spielkarten;
    }

    public ArrayList<Karte> getHandkarten() {
    return handkarten;
    }

    public String zeigeHandkarten(){
        StringBuilder hand = new StringBuilder();
        for(int i = 0; i < handkarten.size(); i++){
            hand.append(i + ": " + handkarten.get(i).toString() + " | ");
        }
        return hand.toString();
    }

    public void print(){
        System.out.println("Handkarten: " + zeigeHandkarten());
        System.out.println("Ablage: " + spielkarten.ablageOben().getFarbe() + " " + spielkarten.ablageOben().getWert());
    }
    public void ziehen(){
        handkarten.add(spielkarten.ziehen());
    }
    public boolean keineKarten(){
        if(handkarten.size() < 1){
            return true;
        }
        return false;
    }
    public void karteAblegen(int index){
        if(handkarten.get(index) != null){
            if(spielkarten.ablageOben().spielbar((handkarten.get(index)))){
                System.out.println("Spieler Nr. " + spielerNummer + " Legt die Karte " + handkarten.get(index).toString());
                spielkarten.ablegen(handkarten.remove(index));
                return;
            }
        }
        System.out.println("Sie können diese Karte nicht spielen");
        System.out.println("Spieler Nr. " + spielerNummer + " zieht eine Karte ");
        handkarten.add(spielkarten.ziehen());

    }
    public void spielen(){

    }
}
