package MauMau;

import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;
public class RealSpieler extends Spieler {
    Scanner scanner = new Scanner(System.in);
    String userEingabe = "";

    public RealSpieler(Kartendeck spielkarten) {
        super(spielkarten);
    }

    public void spielen() {
        while (true) {
            System.out.println("Wollen Sie eine Karte spielen? j: ja, n: nein");
            userEingabe = scanner.nextLine();
            if (userEingabe.equals("n")) {
                System.out.println("Spieler Nr. " + getSpielerNummer() + " zieht eine Karte ");
                getHandkarten().add(getSpielkarten().ziehen());
                break;
            }
            if (userEingabe.equals("j")) {
                while (true){
                    try {
                        System.out.println("Nummer der Karte?");
                        userEingabe = scanner.nextLine();
                        karteAblegen(Integer.parseInt(userEingabe));
                        break;
                    }catch (Exception e){
                        System.out.println("Ungültige Zahl");
                    }
                }
                break;
            }
            System.out.println("falsche Eingabe");
        }
    }
}
