package MauMau;

public class Spiel {
    private int spielerAmZug = 1;
    private RealSpieler[] spieler;
    private Kartendeck kartendeck;

    public Spiel(int anzahl){
        kartendeck = new Kartendeck();
        kartendeck.ablegen(kartendeck.ziehen());
        spieler = new RealSpieler[anzahl];
        for (int i = 0; i < spieler.length; i++) {
            spieler[i] = new RealSpieler(kartendeck);
        }
        spielerAmZug = ((int) Math.random() * anzahl) + 1 ;
    }
    public void naechsterZug(){
        System.out.println("Ablage: " + kartendeck.ablageOben().toString());
        System.out.println("Spieler Nr. " + spielerAmZug + " ist am Zug.");
        System.out.println(spieler[spielerAmZug - 1].zeigeHandkarten());
        spieler[spielerAmZug - 1].spielen();
        spielerAmZug++;
        if(spielerAmZug > spieler.length){
            spielerAmZug = 1;
        }
    }

    public boolean beendet(){
        for (int i = 0; i < spieler.length; i++) {
            if(spieler[i].keineKarten()){
                return true;
            }
        }
        return false;
    }
}
