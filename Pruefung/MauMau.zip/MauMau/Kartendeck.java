package MauMau;

import java.util.ArrayList;

public class Kartendeck {
    private ArrayList<Karte> kartenstapel;
    private ArrayList<Karte> ablage;

    public Kartendeck(){
        kartenstapel = new ArrayList<Karte>();
        ablage = new ArrayList<Karte>();
        for(int i = 7; i <= 14; i++){
            addKarte(new Karte("Herz", i));
            addKarte(new Karte("Pik", i));
            addKarte(new Karte("Karo", i));
            addKarte(new Karte("Kreuz", i));
        }
        ablegen(ziehen());
    }
public Karte ziehen(){
    if(kartenstapel.size() < 1){ //
        while (ablage.size() > 1) { // alles bis auf oberste Ablagekarte
            addKarte(ablage.remove(0));
        }
    }
    return kartenstapel.remove(0);
}

public void ablegen(Karte k){
ablage.add(k);
}
public Karte ablageOben(){
return ablage.get(ablage.size()-1);
}
public void addKarte(Karte k){
    kartenstapel.add((int)(Math.random()*kartenstapel.size()), k);
}
}
