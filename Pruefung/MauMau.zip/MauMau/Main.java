package MauMau;

public class Main {
    public static void main(String[] args){
        Spiel spiel = new Spiel(2);
        while(!spiel.beendet()){
            spiel.naechsterZug();
        }
        System.out.println("Spiel beendet.");
    }
}
